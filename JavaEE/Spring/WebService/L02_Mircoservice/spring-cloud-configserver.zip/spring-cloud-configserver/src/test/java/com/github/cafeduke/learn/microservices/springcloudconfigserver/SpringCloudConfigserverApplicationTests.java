package com.github.cafeduke.learn.microservices.springcloudconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudConfigserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
